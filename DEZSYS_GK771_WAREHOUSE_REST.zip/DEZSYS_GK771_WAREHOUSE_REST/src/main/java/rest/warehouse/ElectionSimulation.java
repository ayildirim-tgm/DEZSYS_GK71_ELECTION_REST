package rest.warehouse;

import rest.model.CountingData;
import rest.model.ElectionData;
import rest.model.VorzugsPerson;

import java.util.ArrayList;

public class ElectionSimulation {
	
	private double getRandomDouble( int inMinimum, int inMaximum ) {

		double number = ( Math.random() * ( (inMaximum-inMinimum) + 1 )) + inMinimum; 
		double rounded = Math.round(number * 100.0) / 100.0; 
		return rounded;
		
	}

	private int getRandomInt( int inMinimum, int inMaximum ) {

		double number = ( Math.random() * ( (inMaximum-inMinimum) + 1 )) + inMinimum; 
		Long rounded = Math.round(number); 
		return rounded.intValue();

	}
	
	public ElectionData getData(String inID ) {
		
		ElectionData data = new ElectionData();
		data.setRegionID( inID );
		data.setRegionName( "Linz Bahnhof" );
		data.setRegionAddress("Bahnhofsstrasse 27/9");
		data.setRegionPostalCode("4020");
		data.setFederalState("Austria");

		ArrayList<VorzugsPerson> vorzugspersonen1 = new ArrayList<>();
		vorzugspersonen1.add(new VorzugsPerson(1, "Gupta Rahul", getRandomInt(50, 100)));
		vorzugspersonen1.add(new VorzugsPerson(2, "Ahuja Ankush", getRandomInt(30, 90)));

		ArrayList<VorzugsPerson> vorzugspersonen2 = new ArrayList<>();
		vorzugspersonen2.add(new VorzugsPerson(1, "Gao Simon", getRandomInt(50, 100)));
		vorzugspersonen2.add(new VorzugsPerson(2, "Ristic Toma", getRandomInt(30, 90)));

		ArrayList<VorzugsPerson> vorzugspersonen3 = new ArrayList<>();
		vorzugspersonen3.add(new VorzugsPerson(1, "Simon Chladeck", getRandomInt(50, 100)));
		vorzugspersonen3.add(new VorzugsPerson(2, "Aran Yildirim", getRandomInt(30, 90)));

		ArrayList<VorzugsPerson> vorzugspersonen4 = new ArrayList<>();
		vorzugspersonen4.add(new VorzugsPerson(1, "Michi Ebner", getRandomInt(50, 100)));
		vorzugspersonen4.add(new VorzugsPerson(2, "Gustav Glatzl", getRandomInt(30, 90)));

		ArrayList<VorzugsPerson> vorzugspersonen5 = new ArrayList<>();
		vorzugspersonen5.add(new VorzugsPerson(1, "Ivan Milev", getRandomInt(50, 100)));
		vorzugspersonen5.add(new VorzugsPerson(2, "Angelo Tan", getRandomInt(30, 90)));


		ArrayList<CountingData> parteien = new ArrayList<>();
		parteien.add(new CountingData("OEVP", getRandomInt(200, 400),vorzugspersonen1));
		parteien.add(new CountingData("SPOE", getRandomInt(200, 400),vorzugspersonen2));
		parteien.add(new CountingData("FPOE", getRandomInt(200, 400),vorzugspersonen3));
		parteien.add(new CountingData("GRUENE", getRandomInt(200, 400),vorzugspersonen4));
		parteien.add(new CountingData("NEOS", getRandomInt(200, 400),vorzugspersonen5));
		data.setCountingData(parteien);

		return data;
		
	}

}
