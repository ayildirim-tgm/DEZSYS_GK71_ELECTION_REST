package rest.model;

public class VorzugsPerson {

    private int listenNummer;
    private String vorname;
    private int stimmenAnzahl;

    public VorzugsPerson(int listenNummer, String vorname, int stimmenAnzahl) {
        this.listenNummer = listenNummer;
        this.vorname = vorname;
        this.stimmenAnzahl = stimmenAnzahl;
    }

    public int getListenNummer() {
        return listenNummer;
    }

    public void setListenNummer(int listenNummer) {
        this.listenNummer = listenNummer;
    }

    public String getVorname() {
        return vorname;
    }

    public void setVorname(String vorname) {
        this.vorname = vorname;
    }

    public int getStimmenAnzahl() {
        return stimmenAnzahl;
    }

    public void setStimmenAnzahl(int stimmenAnzahl) {
        this.stimmenAnzahl = stimmenAnzahl;
    }


}
