package rest.model;

import java.util.ArrayList;

public class CountingData {

    private String partyID;
    private int amountVotes;
    private ArrayList<VorzugsPerson> vorzugsPerson = new ArrayList<>();

    public CountingData(String partyID, int amountVotes, ArrayList<VorzugsPerson> vorzugsPerson) {
        this.partyID = partyID;
        this.amountVotes = amountVotes;
        this.vorzugsPerson = vorzugsPerson;
    }

    public String getPartyID() {
        return partyID;
    }

    public void setPartyID(String partyID) {
        this.partyID = partyID;
    }

    public int getAmountVotes() {
        return amountVotes;
    }

    public void setAmountVotes(int amountVotes) {
        this.amountVotes = amountVotes;
    }

    public ArrayList<VorzugsPerson> getVorzugsPerson() {
        return vorzugsPerson;
    }

    public void setVorzugsPerson(ArrayList<VorzugsPerson> vorzugsPerson) {
        this.vorzugsPerson = vorzugsPerson;
    }

}
